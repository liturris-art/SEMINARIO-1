import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Geolocation } from '@capacitor/geolocation';
import { Camera, CameraResultType, CameraSource, CameraDirection } from '@capacitor/camera';
import { BiometricService } from '../../services/biometric.service';
import { FaceRecognitionService } from '../../services/face-recognition.service';
import { IonicModule, ToastController, AlertController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../services/auth.service';
import { RutasService } from '../../services/rutas/rutas';
import { CallesService } from '../../services/calles/calles';
import { RecorridosService } from '../../services/recorridos/recorridos.service';
import { OfflineSqliteService } from '../../services/offline-sqlite.service';
import { MapViewComponent } from '../../components/map-view/map-view.component';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Preferences } from '@capacitor/preferences';

export type Paso = 1 | 2 | 3 | 4;
const KEY_RECORRIDO_ACTIVO = 'recorridoActivoId';
const KEY_RECORRIDO_INICIO = 'recorridoInicioTimestamp';
const LIMITE_24H_MS   = 24 * 60 * 60 * 1000;
const CHECK_CADA_5MIN = 5 * 60 * 1000;

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, MapViewComponent],
})
export class HomePage implements OnInit, OnDestroy {

  @ViewChild(MapViewComponent) mapView!: MapViewComponent;

  // FIX CIUDADANO: listo = true apenas termina ngOnInit, sin depender de userRole
  listo = false;

  userRole = ''; nombreUsuario = ''; inicialUsuario = '?';
  rutas: any[] = []; calles: any[] = [];
  vehiculos: any[] = []; vehiculoSeleccionado: any = null; rutaSeleccionada: any = null;
  identidadValidada = false; tracking = false; pasoActual: Paso = 1;
  recorridoActivoId: string | null = null;
  lat = 0; lng = 0; velocidad = 0;
  watchId: string | null = null; ultimaLat: number | null = null; ultimaLng: number | null = null;
  distanciaAcumulada = 0; distanciaTotal = 0;
  timerCaducidad: any = null;
  camionActivo = false; distanciaCamion = 0; etaCamion = ''; proximaFecha = ''; proximaHora = '';
  panelAbierto = true;

  // NUEVO: estado del guardado de ruta del conductor
  rutaGuardada = false;
  guardandoRuta = false;

  private hitoEnCurso = false;
  private inicioRecorridoMs: number | null = null;
  private readonly _onOnline = () => this.sincronizarDatos();
  private destroyRef = inject(DestroyRef);

  constructor(
    private http: HttpClient, private authService: AuthService,
    private biometricService: BiometricService, private faceService: FaceRecognitionService,
    private rutasService: RutasService, private callesService: CallesService,
    private recorridosService: RecorridosService, private offlineService: OfflineSqliteService,
    private router: Router, private toastCtrl: ToastController,
    private alertCtrl: AlertController, private cdr: ChangeDetectorRef,
  ) {}

  async ngOnInit() {
    try {
      const perfil = await this.authService.getUserProfile();
      // FIX CIUDADANO: si no hay sesión, userRole queda '' y se muestra vista ciudadano
      this.userRole      = perfil?.rol || '';
      this.nombreUsuario = perfil?.nombre || perfil?.email?.split('@')[0] || 'Visitante';
      this.inicialUsuario = (this.nombreUsuario[0] || 'V').toUpperCase();
    } catch {
      // Sin sesión: ciudadano anónimo — se muestra vista ciudadano igualmente
      this.userRole      = '';
      this.nombreUsuario = 'Visitante';
      this.inicialUsuario = 'V';
    } finally {
      // listo = true SIEMPRE, con o sin sesión
      this.listo = true;
      this.cdr.detectChanges();
    }

    this.cargarDatosMapa();

    if (this.esConductor()) {
      this.cargarVehiculos();
      await this.verificarRecorridoGuardado();
    } else {
      this.simularEstadoCamion();
      this.calcularProximaRecoleccion();
    }

    window.addEventListener('online', this._onOnline);
  }

  ngOnDestroy() {
    if (this.watchId) Geolocation.clearWatch({ id: this.watchId });
    if (this.timerCaducidad) clearInterval(this.timerCaducidad);
    window.removeEventListener('online', this._onOnline);
  }

  // Un conductor tiene sesión Y rol conductor. Todo lo demás = ciudadano.
  esConductor() { return this.userRole?.toLowerCase().trim() === 'conductor'; }
  volver()      { this.router.navigateByUrl('/menu'); }
  togglePanel() { this.panelAbierto = !this.panelAbierto; }

  pasoCompletado(p: number): boolean {
    if (p === 1) return !!this.vehiculoSeleccionado;
    if (p === 2) return !!this.rutaSeleccionada;
    if (p === 3) return this.identidadValidada;
    if (p === 4) return this.tracking;
    return false;
  }
  avanzarPaso() { if (this.pasoActual < 4) this.pasoActual = (this.pasoActual + 1) as Paso; }

  cargarDatosMapa() {
    this.rutasService.getRutas().pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(r => { this.rutas = r?.data || []; });
    this.callesService.getCalles().pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(c => { this.calles = c?.data || []; });
  }

  cargarVehiculos() {
    this.http.get<any>(`${environment.apiUrl}/vehiculos?perfil_id=${environment.perfilUrl}`)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({ next: r => (this.vehiculos = r?.data || r), error: e => console.error('Error vehículos:', e) });
  }

  onVehiculoChange() { if (this.vehiculoSeleccionado && this.pasoActual === 1) this.avanzarPaso(); }

  onRutaChange() {
    // Resetear estado de guardado cuando cambia la ruta
    this.rutaGuardada = false;
    if (this.rutaSeleccionada && this.pasoActual === 2) this.avanzarPaso();
  }

  // ── NUEVO: Guardar ruta seleccionada en el mapa ───────────
  // El conductor puede marcar su ruta asignada en el mapa y guardarla
  // para tener un registro local de la ruta del día.
  async guardarRutaSeleccionada() {
    if (!this.rutaSeleccionada) {
      this.showToast('Selecciona una ruta primero', 'warning');
      return;
    }

    this.guardandoRuta = true;
    try {
      // Guardar en Preferences: ruta + vehículo + timestamp
      const registro = {
        rutaId:       this.rutaSeleccionada.id,
        nombreRuta:   this.rutaSeleccionada.nombre_ruta,
        vehiculoId:   this.vehiculoSeleccionado?.id   || null,
        placa:        this.vehiculoSeleccionado?.placa || null,
        fechaRegistro: new Date().toISOString(),
        conductor:    this.nombreUsuario,
      };

      await Preferences.set({
        key:   'rutaRegistrada',
        value: JSON.stringify(registro),
      });

      // También resaltar la ruta en el mapa
      this.mapView?.destacarRuta(this.rutaSeleccionada);

      this.rutaGuardada = true;
      this.showToast(`✅ Ruta "${this.rutaSeleccionada.nombre_ruta}" guardada`, 'success');
    } catch (e) {
      console.error('Error guardando ruta:', e);
      this.showToast('Error al guardar la ruta', 'danger');
    } finally {
      this.guardandoRuta = false;
    }
  }

  // ── Validar identidad facial ──────────────────────────────
  async validarIdentidad() {
    const tieneReferencia = await this.faceService.tieneDescriptorGuardado();
    if (!tieneReferencia) { this.showToast('⚠️ No hay foto de referencia. Vuelve a registrarte.', 'warning'); return; }
    try {
      this.showToast('📸 Toma la foto mirando de frente', 'warning');
      const foto = await Camera.getPhoto({
        quality: 85, resultType: CameraResultType.Base64,
        source: CameraSource.Camera, direction: CameraDirection.Front, saveToGallery: false,
      });
      if (!foto.base64String) { this.showToast('No se pudo obtener la foto', 'danger'); return; }
      this.showToast('🔍 Verificando identidad...', 'warning');
      const resultado = await this.faceService.verificarIdentidad(foto.base64String);
      if (resultado.error) { this.showToast(`❌ ${resultado.error}`, 'danger'); return; }
      if (resultado.verificado) {
        this.identidadValidada = true; this.avanzarPaso();
        this.showToast(`✅ Identidad verificada (confianza: ${resultado.confianza}%)`, 'success');
      } else {
        this.showToast(`❌ Rostro no reconocido (${resultado.confianza}%). Intenta con buena luz.`, 'danger');
      }
    } catch { this.showToast('Verificación cancelada', 'warning'); }
  }

  // ── Iniciar recorrido ─────────────────────────────────────
  async iniciarRecorrido() {
    if (!this.vehiculoSeleccionado) return this.showToast('Seleccione un vehículo', 'warning');
    if (!this.rutaSeleccionada)     return this.showToast('Seleccione una ruta', 'warning');
    if (!this.identidadValidada)    return this.showToast('Valide su identidad', 'warning');
    try {
      const rec = await this.recorridosService.iniciarRecorrido(this.rutaSeleccionada?.id, this.vehiculoSeleccionado?.id);
      this.recorridoActivoId = rec.id;
      this.tracking = true; this.pasoActual = 4; this.panelAbierto = false;
      this.distanciaTotal = 0; this.distanciaAcumulada = 0;
      this.ultimaLat = null; this.ultimaLng = null; this.hitoEnCurso = false;

      await this._persistirRecorridoActivo(rec.id);
      this._iniciarTimerCaducidad();
      await this.obtenerUbicacionInicial();
      await this.sincronizarDatos();

      this.watchId = await Geolocation.watchPosition({ enableHighAccuracy: true }, pos => {
        if (!pos) return;
        this.lat = pos.coords.latitude; this.lng = pos.coords.longitude;
        this.velocidad = Math.round((pos.coords.speed || 0) * 3.6);
        this.mapView?.actualizarCamion(this.lat, this.lng, this.velocidad);
        this.procesarDistancia(); this.cdr.detectChanges();
      });
      this.showToast('🚛 Recorrido iniciado', 'success');
    } catch (e: any) {
      const msg = e?.error?.message || e?.message || 'Error al iniciar el recorrido. Verifica tu conexión.';
      this.showToast(`❌ ${msg}`, 'danger');
    }
  }

  async detenerRecorrido() {
    if (!this.tracking) return;
    if (this.recorridoActivoId) await this.recorridosService.finalizarRecorrido(this.recorridoActivoId);
    this.tracking = false; this.recorridoActivoId = null; this.hitoEnCurso = false; this.inicioRecorridoMs = null;
    if (this.watchId) { Geolocation.clearWatch({ id: this.watchId }); this.watchId = null; }
    if (this.timerCaducidad) { clearInterval(this.timerCaducidad); this.timerCaducidad = null; }
    await this._borrarRecorridoGuardado();
    this.panelAbierto = true; this.pasoActual = 1;
    this.showToast('Recorrido finalizado', 'success');
  }

  async obtenerUbicacionInicial() {
    const pos = await Geolocation.getCurrentPosition();
    this.lat = pos.coords.latitude; this.lng = pos.coords.longitude;
  }

  procesarDistancia() {
    if (this.ultimaLat == null || this.ultimaLng == null) {
      this.ultimaLat = this.lat; this.ultimaLng = this.lng; this.enviarPosicion(this.lat, this.lng); return;
    }
    const d = this.calcularDistancia(this.ultimaLat, this.ultimaLng, this.lat, this.lng);
    if (d >= 0.005) this.enviarPosicion(this.lat, this.lng);
    this.distanciaAcumulada += d; this.distanciaTotal += d;
    if (this.distanciaAcumulada >= 1 && !this.hitoEnCurso) { this.dispararHito(); this.distanciaAcumulada = 0; }
    this.ultimaLat = this.lat; this.ultimaLng = this.lng;
  }

  calcularDistancia(la1: number, lo1: number, la2: number, lo2: number) {
    const R = 6371, dL = this.toRad(la2 - la1), dO = this.toRad(lo2 - lo1);
    const a = Math.sin(dL/2)**2 + Math.cos(this.toRad(la1)) * Math.cos(this.toRad(la2)) * Math.sin(dO/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }
  toRad(v: number) { return v * Math.PI / 180; }

  async enviarPosicion(lat: number, lon: number, foto?: string | null) {
    if (!this.recorridoActivoId) return;
    if (navigator.onLine) {
      try { await this.recorridosService.registrarPosicion(this.recorridoActivoId, lat, lon, foto); }
      catch { await this.offlineService.guardar({ recorridoId: this.recorridoActivoId, lat, lon, foto: foto ?? null, timestamp: Date.now() }); }
    } else {
      await this.offlineService.guardar({ recorridoId: this.recorridoActivoId, lat, lon, foto: foto ?? null, timestamp: Date.now() });
    }
  }

  async sincronizarDatos() {
    if (!navigator.onLine) return;
    const pendientes = await this.offlineService.obtenerTodos();
    if (!pendientes.length) return;
    let todosOk = true;
    for (const item of pendientes) {
      try { await this.recorridosService.registrarPosicion(item.recorridoId, item.lat, item.lon, item.foto); }
      catch { todosOk = false; break; }
    }
    if (todosOk) { await this.offlineService.limpiar(); }
  }

  async dispararHito() {
    if (this.hitoEnCurso) return;
    this.hitoEnCurso = true;
    const alert = await this.alertCtrl.create({
      header: '📍 Hito de control — 1 km',
      message: '¿Deseas capturar una fotografía de evidencia de recolección?',
      buttons: [
        { text: 'Omitir', role: 'cancel', handler: () => { this.enviarPosicion(this.lat, this.lng, null); this.hitoEnCurso = false; } },
        { text: '📸 Tomar foto', handler: async () => { await this._capturarFotoHito(); this.hitoEnCurso = false; } },
      ],
    });
    await alert.present();
  }

  private async _capturarFotoHito() {
    try {
      const img = await Camera.getPhoto({ quality: 50, resultType: CameraResultType.Base64, source: CameraSource.Camera, saveToGallery: false });
      if (img.base64String) { await this.enviarPosicion(this.lat, this.lng, img.base64String); this.showToast('✅ Foto de evidencia registrada', 'success'); }
      else { await this.enviarPosicion(this.lat, this.lng, null); }
    } catch { await this.enviarPosicion(this.lat, this.lng, null); this.showToast('Hito registrado sin foto', 'warning'); }
  }

  private _iniciarTimerCaducidad() {
    if (this.timerCaducidad) clearInterval(this.timerCaducidad);
    this.timerCaducidad = setInterval(() => {
      if (!this.inicioRecorridoMs || !this.tracking) return;
      if (Date.now() - this.inicioRecorridoMs >= LIMITE_24H_MS) {
        clearInterval(this.timerCaducidad); this.timerCaducidad = null;
        this._manejarCaducidad();
      }
    }, CHECK_CADA_5MIN);
  }

  private async _manejarCaducidad() {
    this.tracking = false;
    if (this.watchId) { Geolocation.clearWatch({ id: this.watchId }); this.watchId = null; }
    if (this.timerCaducidad) { clearInterval(this.timerCaducidad); this.timerCaducidad = null; }
    await this._borrarRecorridoGuardado();
    const alert = await this.alertCtrl.create({
      header: '⏰ Recorrido suspendido',
      message: 'El recorrido superó el límite de 24 horas y ha sido suspendido automáticamente.',
      buttons: [{ text: 'Entendido', handler: () => { this.pasoActual = 1; this.panelAbierto = true; } }],
    });
    await alert.present();
  }

  private async verificarRecorridoGuardado() {
    try {
      const { value: id }    = await Preferences.get({ key: KEY_RECORRIDO_ACTIVO });
      if (!id) return;
      const { value: tsStr } = await Preferences.get({ key: KEY_RECORRIDO_INICIO });
      const inicioMs         = tsStr ? parseInt(tsStr, 10) : 0;
      const transcurrido     = Date.now() - inicioMs;

      if (transcurrido >= LIMITE_24H_MS || !inicioMs) {
        await this._borrarRecorridoGuardado();
        this.showToast('El recorrido anterior fue suspendido por superar 24 h.', 'warning');
      } else {
        const mins = Math.floor((LIMITE_24H_MS - transcurrido) / 60000);
        const alert = await this.alertCtrl.create({
          header: 'Recorrido en curso',
          message: `Tienes un recorrido activo. Le quedan ${mins} minutos. ¿Deseas retomarlo?`,
          buttons: [
            { text: 'No, descartar', role: 'cancel', handler: () => this._borrarRecorridoGuardado() },
            { text: 'Sí, retomar', handler: () => {
              this.recorridoActivoId = id; this.inicioRecorridoMs = inicioMs;
              this.tracking = true; this.pasoActual = 4; this.panelAbierto = false;
              this._iniciarTimerCaducidad(); this._reanudarWatchGPS();
            }},
          ],
        });
        await alert.present();
      }
    } catch (e) { console.warn('No se pudo verificar recorrido guardado:', e); }
  }

  private async _persistirRecorridoActivo(id: string) {
    await Preferences.set({ key: KEY_RECORRIDO_ACTIVO, value: id });
    await Preferences.set({ key: KEY_RECORRIDO_INICIO, value: Date.now().toString() });
  }

  private async _borrarRecorridoGuardado() {
    await Preferences.remove({ key: KEY_RECORRIDO_ACTIVO });
    await Preferences.remove({ key: KEY_RECORRIDO_INICIO });
    this.recorridoActivoId = null; this.inicioRecorridoMs = null;
  }

  private async _reanudarWatchGPS() {
    this.watchId = await Geolocation.watchPosition({ enableHighAccuracy: true }, pos => {
      if (!pos) return;
      this.lat = pos.coords.latitude; this.lng = pos.coords.longitude;
      this.velocidad = Math.round((pos.coords.speed || 0) * 3.6);
      this.mapView?.actualizarCamion(this.lat, this.lng, this.velocidad);
      this.procesarDistancia(); this.cdr.detectChanges();
    });
  }

  simularEstadoCamion() {
    this.recorridosService.getRecorridos().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(res => {
      const activos = (res?.data || []).filter((r: any) => !r.fin);
      this.camionActivo = activos.length > 0;
      if (this.camionActivo) {
        this.distanciaCamion = Math.round(Math.random() * 800 + 200);
        const mins = Math.round(this.distanciaCamion / 300);
        this.etaCamion = mins < 1 ? 'Llegando' : `~${mins} min`;
      }
    });
  }

  calcularProximaRecoleccion() {
    const dias = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    const next = new Date(); next.setDate(next.getDate() + 2);
    this.proximaFecha = `${dias[next.getDay()]} ${next.getDate()}`; this.proximaHora = '07:00 AM';
  }

  private async showToast(msg: string, color: 'success' | 'warning' | 'danger') {
    const t = await this.toastCtrl.create({ message: msg, color, duration: 3000, position: 'top' });
    await t.present();
  }

  get latStr()  { return this.lat  ? this.lat.toFixed(6)  : '—'; }
  get lngStr()  { return this.lng  ? this.lng.toFixed(6)  : '—'; }
  get distStr() { return this.distanciaTotal.toFixed(2); }
}
