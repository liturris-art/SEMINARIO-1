import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { SupabaseService } from '../supabase.service';

export interface Recorrido {
  id:          string;
  ruta_id:     string;
  vehiculo_id: string;
  perfil_id:   string;
  inicio:      string;
  fin?:        string;
}

// ─────────────────────────────────────────────────────────────────────────────
// RecorridosService — ACTUALIZADO
//
// Cambios respecto a la versión anterior:
//
//  1. DOBLE PERSISTENCIA REMOTA (spec §2):
//     - Servidor del docente : apirecoleccion.gonzaloandreslucio.com  ← ya existía
//     - Base de datos propia : tabla "posiciones" en Supabase          ← NUEVO
//
//  2. FOTO BASE64 EN HITO (spec §3):
//     - registrarPosicion() acepta ahora el parámetro opcional `foto`
//     - La foto se envía al endpoint del docente y también se persiste en Supabase
//
//  3. VALIDACIÓN DE CADUCIDAD 24 H (spec §5):
//     - verificarCaducidad() comprueba si el recorrido activo lleva > 24 h
//     - Si caducó, lo marca como "Suspendido" en Supabase y devuelve false
//
// SUPABASE — TABLAS NECESARIAS:
// Ejecuta este SQL en el editor de Supabase de tu proyecto:
//
//   CREATE TABLE IF NOT EXISTS posiciones (
//     id            UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//     recorrido_id  TEXT        NOT NULL,
//     perfil_id     TEXT        NOT NULL,
//     lat           FLOAT       NOT NULL,
//     lon           FLOAT       NOT NULL,
//     foto_base64   TEXT,
//     creado_en     TIMESTAMPTZ DEFAULT now()
//   );
//
//   CREATE TABLE IF NOT EXISTS recorridos_app (
//     id            UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//     recorrido_id  TEXT        NOT NULL UNIQUE,
//     ruta_id       TEXT,
//     vehiculo_id   TEXT,
//     perfil_id     TEXT        NOT NULL,
//     estado        TEXT        DEFAULT 'activo',   -- 'activo' | 'finalizado' | 'suspendido'
//     inicio_en     TIMESTAMPTZ DEFAULT now(),
//     fin_en        TIMESTAMPTZ
//   );
//
// ─────────────────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class RecorridosService {

  private apiUrl   = environment.apiUrl;
  private perfilId = environment.perfilUrl;

  constructor(
    private http:     HttpClient,
    private supabase: SupabaseService,
  ) {}

  // ── 1. INICIAR RECORRIDO ──────────────────────────────────
  // Llama al endpoint del docente y también registra el recorrido en Supabase.
  async iniciarRecorrido(rutaId: string, vehiculoId: string): Promise<Recorrido> {
    // 1a. Registrar en la API del docente
    const rec = await firstValueFrom(
      this.http.post<Recorrido>(`${this.apiUrl}/recorridos/iniciar`, {
        ruta_id:     rutaId,
        vehiculo_id: vehiculoId,
        perfil_id:   this.perfilId,
      }),
    );

    // 1b. Registrar en tabla propia de Supabase (analítica interna)
    try {
      const db = this.supabase.getClient();
      await db.from('recorridos_app').upsert({
        recorrido_id: rec.id,
        ruta_id:      rutaId,
        vehiculo_id:  vehiculoId,
        perfil_id:    this.perfilId,
        estado:       'activo',
        inicio_en:    new Date().toISOString(),
      });
    } catch (e) {
      // No bloquear el flujo si Supabase falla; la API del docente ya registró
      console.warn('Supabase: no se pudo registrar recorrido', e);
    }

    return rec;
  }

  // ── 2. REGISTRAR POSICIÓN CON DOBLE PERSISTENCIA ─────────
  // Envía lat/lon (y foto opcional) al docente Y a Supabase.
  async registrarPosicion(
    recorridoId: string,
    lat:         number,
    lon:         number,
    foto?:       string | null,   // Base64 de la foto del hito (spec §3)
  ): Promise<void> {

    // 2a. Endpoint del docente (obligatorio para auditoría)
    await firstValueFrom(
      this.http.post<void>(
        `${this.apiUrl}/recorridos/${recorridoId}/posiciones`,
        { lat, lon, perfil_id: this.perfilId },
      ),
    );

    // 2b. Supabase — analítica interna (spec §2 "doble persistencia remota")
    try {
      const db = this.supabase.getClient();
      await db.from('posiciones').insert({
        recorrido_id: recorridoId,
        perfil_id:    this.perfilId,
        lat,
        lon,
        foto_base64:  foto ?? null,   // spec §3: imagen en Base64
        creado_en:    new Date().toISOString(),
      });
    } catch (e) {
      console.warn('Supabase: no se pudo registrar posición', e);
    }
  }

  // ── 3. FINALIZAR RECORRIDO ────────────────────────────────
  async finalizarRecorrido(recorridoId: string): Promise<void> {
    try {
      const db = this.supabase.getClient();
      await db.from('recorridos_app')
        .update({ estado: 'finalizado', fin_en: new Date().toISOString() })
        .eq('recorrido_id', recorridoId);
    } catch (e) {
      console.warn('Supabase: no se pudo finalizar recorrido', e);
    }
  }

  // ── 4. VALIDAR CADUCIDAD 24 H (spec §5) ──────────────────
  // Llama esto al iniciar la app o al reanudar un recorrido.
  // Devuelve true si el recorrido sigue vigente, false si ya caducó.
  async verificarCaducidad(recorridoId: string): Promise<boolean> {
    try {
      const db  = this.supabase.getClient();
      const { data, error } = await db
        .from('recorridos_app')
        .select('inicio_en, estado')
        .eq('recorrido_id', recorridoId)
        .single();

      if (error || !data) return false;
      if (data.estado !== 'activo') return false;

      const inicio  = new Date(data.inicio_en).getTime();
      const ahora   = Date.now();
      const horasTranscurridas = (ahora - inicio) / (1000 * 60 * 60);

      if (horasTranscurridas > 24) {
        // Marcar como suspendido (spec §5)
        await db.from('recorridos_app')
          .update({ estado: 'suspendido', fin_en: new Date().toISOString() })
          .eq('recorrido_id', recorridoId);

        console.warn(`Recorrido ${recorridoId} suspendido por superar 24 h`);
        return false;   // inhabilitado
      }

      return true;  // vigente
    } catch (e) {
      console.warn('No se pudo verificar caducidad:', e);
      return true;  // si falla la consulta, dejamos continuar por defecto
    }
  }

  // ── 5. LISTAR RECORRIDOS ──────────────────────────────────
  // FIX #7/#8: leer recorridos desde Supabase (historial y reportes locales)
  async getRecorridosLocales(): Promise<Recorrido[]> {
    try {
      const db = this.supabase.getClient();
      const { data, error } = await db
        .from('recorridos_app')
        .select('*')
        .eq('perfil_id', this.perfilId)
        .order('inicio_en', { ascending: false });
      if (error) throw error;
      return (data || []).map((r: any) => ({
        id: r.recorrido_id, ruta_id: r.ruta_id,
        vehiculo_id: r.vehiculo_id, perfil_id: r.perfil_id,
        inicio: r.inicio_en, fin: r.fin_en,
      }));
    } catch (e) { console.warn('getRecorridosLocales error:', e); return []; }
  }

  getRecorridos() {
    return this.http.get<{ data: Recorrido[] }>(
      `${this.apiUrl}/recorridos?perfil_id=${this.perfilId}`,
    );
  }
}
